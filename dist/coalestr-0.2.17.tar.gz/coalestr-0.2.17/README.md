# coalestr-python

`coalestr` is a python package for using the **genomic transmission graph** to model the transmission dynamics and genomic diversity of a recombining parasite population. 

You can find tutorials and worked examples at [d-kwiat.github.io/gtg/](https://d-kwiat.github.io/gtg/).